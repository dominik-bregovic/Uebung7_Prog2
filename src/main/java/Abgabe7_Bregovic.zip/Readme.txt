5.18.2021
Bregovic Dominik

Tryed to keep the printed output like in our given excamples.

-I implemented a ingonreLine method, which could ignore each line with a empty fiel,
 but would this change my output drasticly. It also occures to me that without the ignoreLine method the 
 output was exatly the same as yours, except of the two interprets "The Weekend" and "Leony"

-I figured that you may had checked more dezimalpoints that i did but when i tried to go to the last 
 decimal-point it changed the list again completly
 We discussed this in class either i think....

-The logfile gets build in the root folder of the project.

-This is a mavenprojekt
